let nombre = prompt("HOLA! ¿CÓMO SE LLAMA?" )
alert("BIENVENIDO " + nombre + " A TRES EN RAYA, DISFRUTA EL JUEGO Y MUCHA SUERTE")









